1. Install Python3.x.
2. Download and save BackendAssessment_revision.py file in any folder.
3. Download courses.csv, marks.csv, students.csv and tests.csv files in the same folder where BackendAssessment file is saved.
4. Open python shell and change the current directory to the same directory where program file is saved 
5. Execute command "from BackendAssessment_revision import report_card"
6. Again execute command "report_card("courses.csv", "students.csv","tests.csv","marks.csv")
7. CSV files should be passed as per the command mentioned above. Incorrect files or random passing files will lead to error.
7. Output file "report_card.txt" will be saved in the current directory.
8. Do not change the column headers of any of the csv files passed. You can change modify the contents of files passed
9. You can read Details of class using help(report_card) command.