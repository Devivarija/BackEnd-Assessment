#!/usr/bin/env python
# coding: utf-8

# In[214]:


# Program to generate report card on the basis of details in 4 csv files passed namely: courses, students, tests, marks
import csv
class report_card:
    '''Pass 4 files in the order of courses, students, tests and marks'''
    def __init__(self, courses, students, tests, marks):
        self.courses = courses
        self.students = students
        self.tests = tests
        self.marks = marks
        self.readfiles()
        self.total_check_test()
        self.course_tests_enrolled_check()
        self.calculate_percentage_each_course()
        self.final_aggregate()
        self.log_report()
        
    def readfiles(self):
        with open(self.courses) as cfile:
            creader = csv.reader(cfile)
            next(creader, None)
            mycourse = {rows[0]:[rows[1], rows[2]] for rows in creader}
            
        self.mycourse = mycourse
        with open(self.students) as sfile:
            sreader  = csv.reader(sfile)
            next(sreader, None)
            mystudent = {rows[0]:rows[1] for rows in sreader}
           
        self.mystudent = mystudent
        
        #Nested Dictionary for tests.csv
        test_id = {}
        mytests = {}
        for key in mycourse:
            with open(self.tests) as tfile:
                treader = csv.reader(tfile)
                next(treader, None)
                for t in treader:
                    if int(key) == int(t[1]):
                        test_id[t[0]] = t[2]
                        mytests[key] = test_id
                test_id = {}          

        self.mytests = mytests
    
        # Nested dictionary for marks.csv 
        mymarks = {}
        details = {}
        for key in mystudent:
            with open(self.marks) as mfile:
                reader = (csv.reader(mfile))
                next(reader, None)
                for row in reader:
                    if int(key)==int(row[1]):
                        
                        details[row[0]] = row[2]
                        mymarks[key] = details
                details = {}
        self.mymarks = mymarks
        
    def total_check_test(self):
        total_test = {}
        mytests = self.mytests
        x = 0
        for i, j in mytests.items():
            for key, value in j.items():
                x = int(value) + x
                
            if x!=100:
                total_test[i] = "Not equals to 100"
            else:
                total_test[i] = x    
            x=0 
       
        self.total_test = total_test
        
    def course_tests_enrolled_check(self):
        mymarks = self.mymarks
        mytests = self.mytests
        map_test_mark = {}
        
        for student_id, test_details in mymarks.items():
            
            for key, value in mytests.items():
                if (all(element in test_details.keys() for element in value.keys())):
                    pass
                                               
                else:
                    map_test_mark[student_id] = [key, "Student has not completed this course"] 
                 
        self.map_test_mark = map_test_mark
                           
    def calculate_percentage_each_course(self):
        ls = []
        final = {}
        individual_percentage ={}
        mymarks = self.mymarks
        mytests = self.mytests
        for studentid, testgot in mymarks.items():
            for courseid, test_total in mytests.items():
                for m, n in zip(testgot.values(), testgot.keys()):
                    for i, j in zip(test_total.values(), test_total.keys()):
                        if j == n:
                            each_test_perc = (int(m) * int(i))/100
                            ls.append(each_test_perc)

                final[courseid] = format(sum(ls), "0.2f")
                ls= []
            final_new = {k:v for k, v in final.items() if v!= "0.00"}
            individual_percentage[studentid] = final_new
            final = {}
        self.individual_percentage = individual_percentage    
        
       

    def final_aggregate(self):
        final_percentage = {}
        individual_percentage = self.individual_percentage
        for key, value in individual_percentage.items():
            aggregate = 0
            for v in value.values():
                aggregate = aggregate + float(v)
            aggregate = (aggregate/(len(value)*100)) *100
            final_percentage[key] = format(aggregate, "0.2f")
          
        self.final_percentage = final_percentage
       
    
    def log_report(self):
        mystudent = self.mystudent
        final_percentage = self.final_percentage
        mycourse = self.mycourse
        individual_percentage = self.individual_percentage
        map_test_mark = self.map_test_mark
        total_test = self.total_test
        with open("report_card.txt", "w") as reportfile:
            for studentid, percent_details in individual_percentage.items():
                reportfile.write("Student ID:"+studentid+ "    Name:"+ mystudent[studentid]+"\n")
                reportfile.write("Total Average:"+final_percentage[studentid]+"%\n")
                for courseid, marks in percent_details.items():
                    reportfile.write("\t\tCourse:"+mycourse[courseid][0]+", Teacher:"+mycourse[courseid][1]+"\n")
                    if total_test[courseid] == 100:
                        reportfile.write("\t\tFinal Grade:"+marks+"%\n\n\n")
                    else:
                        reportfile.write("\t\tTests total should be equal to 100 for this course.\n\n")
                if studentid in map_test_mark:
                    reportfile.write("\t\tStudent has not completed course:"+mycourse[map_test_mark[studentid][0]][0]+"\n\n\n")
        
        reportfile.close()
                    
                    
                        
                        
                


# In[ ]:




